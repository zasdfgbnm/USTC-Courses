
   documentation for emu8086 microprocessor emulator
   =================================================
	 
   to view documentation open c:\emu8086\documentation\_documentation_index.html 

   for more print-friendly/frameless version open c:\emu8086\documentation\help.html
   
   online version of documentation is available:

   http://www.emu8086.com/dr/index.html

   (can be updated without a notice)
   


   
   