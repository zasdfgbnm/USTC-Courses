

   these examples are designed for emu8086 assembler and microprocessor emulator.
